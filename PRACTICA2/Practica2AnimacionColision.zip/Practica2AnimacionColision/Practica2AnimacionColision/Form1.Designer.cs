﻿namespace Practica2AnimacionColision
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            PCT_CANVAS = new PictureBox();
            TIMER = new System.Windows.Forms.Timer(components);
            panel1 = new Panel();
            SIZE = new Label();
            SPEED = new Label();
            DIR = new Label();
            BTN = new Button();
            ((System.ComponentModel.ISupportInitialize)PCT_CANVAS).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // PCT_CANVAS
            // 
            PCT_CANVAS.Location = new Point(12, 138);
            PCT_CANVAS.Name = "PCT_CANVAS";
            PCT_CANVAS.Size = new Size(1000, 500);
            PCT_CANVAS.TabIndex = 0;
            PCT_CANVAS.TabStop = false;
            PCT_CANVAS.Tag = "PCT_CANVAS";
            // 
            // TIMER
            // 
            TIMER.Enabled = true;
            TIMER.Interval = 10;
            TIMER.Tag = "TIMER";
            TIMER.Tick += TIMER_Tick;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDarkDark;
            panel1.Controls.Add(SIZE);
            panel1.Controls.Add(SPEED);
            panel1.Controls.Add(DIR);
            panel1.Controls.Add(BTN);
            panel1.Location = new Point(12, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(1000, 118);
            panel1.TabIndex = 1;
            panel1.Paint += panel1_Paint;
            // 
            // SIZE
            // 
            SIZE.AutoSize = true;
            SIZE.Location = new Point(562, 40);
            SIZE.Name = "SIZE";
            SIZE.Size = new Size(124, 32);
            SIZE.TabIndex = 3;
            SIZE.Text = "WELCOME";
            // 
            // SPEED
            // 
            SPEED.AutoSize = true;
            SPEED.Location = new Point(314, 69);
            SPEED.Name = "SPEED";
            SPEED.Size = new Size(124, 32);
            SPEED.TabIndex = 2;
            SPEED.Text = "WELCOME";
            // 
            // DIR
            // 
            DIR.AutoSize = true;
            DIR.Location = new Point(314, 18);
            DIR.Name = "DIR";
            DIR.Size = new Size(124, 32);
            DIR.TabIndex = 1;
            DIR.Text = "WELCOME";
            // 
            // BTN
            // 
            BTN.BackColor = Color.DarkGoldenrod;
            BTN.Location = new Point(47, 40);
            BTN.Name = "BTN";
            BTN.Size = new Size(150, 46);
            BTN.TabIndex = 0;
            BTN.Text = "EXE";
            BTN.UseVisualStyleBackColor = false;
            BTN.Click += BTN_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1021, 646);
            Controls.Add(panel1);
            Controls.Add(PCT_CANVAS);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)PCT_CANVAS).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox PCT_CANVAS;
        private System.Windows.Forms.Timer TIMER;
        private Panel panel1;
        private Label SIZE;
        private Label SPEED;
        private Label DIR;
        private Button BTN;
    }
}
