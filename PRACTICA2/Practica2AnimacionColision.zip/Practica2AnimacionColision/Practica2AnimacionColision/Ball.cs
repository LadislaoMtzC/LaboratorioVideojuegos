﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica2AnimacionColision
{
    internal class Ball
    {

        public float diameter, radio;
        public int speedX, speedY;
        public Point pos, dir;
        public Size space;

        public Ball(Random rand, Size size) {
            space = size;
            
            
            diameter = rand.Next(15, 70);
            pos = new Point(rand.Next(0, size.Width), rand.Next(0, size.Height));
            dir = new Point(1 + rand.Next(size.Width) / 100, 1 + rand.Next(size.Height) / 100);

            speedX = rand.Next(-10, 10);
            speedY = rand.Next(-10, 10);

            diameter = rand.Next(15, 70);
            radio = diameter / 2;

        }
        public void Render(Graphics g) {
            g.FillEllipse(Brushes.Yellow, pos.X - radio, pos.Y - radio, diameter, diameter);
            g.DrawEllipse(Pens.AliceBlue, pos.X - radio, pos.Y - radio, diameter, diameter);
            g.FillEllipse(Brushes.Gray, pos.X - 2, pos.Y - 2, 4, 4);

        }


        //CON ESTA FUNCION SE OBTIENE EL RECTANGULO CIRCUNSCRITO EN LA PELOTA
        private Rectangle GetBallRectangle()
        {
            return new Rectangle(pos.X - (int)radio, pos.Y - (int)radio, (int)diameter + 1, (int)diameter + 1);
        }

        public void Update()
        {

           if ((pos.X - radio) <= 2) { 
                
                pos.X = 3 + (int) radio;
                speedX *= -1;
            }

            if ((pos.X + radio) >= space.Width - 2) {

                pos.X = (int)(space.Width - radio);
                speedX *= -1;
            }

            if ((pos.Y - radio) <= 2)
            {
                pos.Y = 3 + (int) radio;
                speedY *= -1;    

            }

            if ((pos.Y + radio) >= space.Height - 2)
            {
                pos.Y = (int)(space.Height - radio);
                speedY *= -1;   

            }


            //SE DECLARAN LOS RECTANGULOS ANTES DIBUJADOS
            Rectangle rect1 = new Rectangle(space.Width / 5, space.Height - 350, 200, 350);
            Rectangle rect2 = new Rectangle((space.Width / 5) * 3, space.Height - 300, 250, 300);



            //SE VERIFICA SI EL RECTANGULO CIRCUNSCRITO EN LA PELOTA INTERSECTA LOS OTROS RECTANGULOS
            if (rect1.IntersectsWith(GetBallRectangle()) || rect2.IntersectsWith(GetBallRectangle()))
            {
                //SE GENERA UNA COLISION Y SE CAMBIA EL SIGNO DE AMBOS EJES

                speedX *= -1;
                speedY *= -1;
            }


            float desplazamientoX = speedX * (float)Math.Cos(dir.X);
            float desplazamientoY = speedY * (float)Math.Sin(dir.X);

            pos.X = (int)(pos.X + desplazamientoX);
            pos.Y = (int)(pos.Y + desplazamientoY);

        }

       



    }
}
