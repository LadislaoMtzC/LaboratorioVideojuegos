using Microsoft.VisualBasic.Devices;

namespace Practica2AnimacionColision
{
    public partial class Form1 : Form
    {
        Ball ball;
        Bitmap bmp;
        Graphics g;

        public Form1()
        {
            InitializeComponent();
            Init();
        }

        private void Init()
        {
            ball = new Ball(new Random(), PCT_CANVAS.Size);
            bmp = new Bitmap(PCT_CANVAS.Width, PCT_CANVAS.Height);
            g = Graphics.FromImage(bmp);
            PCT_CANVAS.Image = bmp;
            
        }




        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TIMER_Tick(object sender, EventArgs e)
        {
            g.Clear(Color.Transparent);
            g.FillRectangle(Brushes.Green, PCT_CANVAS.Width / 5, PCT_CANVAS.Height - 350,200, 350);
            g.DrawRectangle(Pens.Blue, PCT_CANVAS.Width / 5, PCT_CANVAS.Height - 350, 200, 350);
            g.FillRectangle(Brushes.Green, (PCT_CANVAS.Width / 5)*3, PCT_CANVAS.Height - 300, 250, 300);
            g.DrawRectangle(Pens.Blue, (PCT_CANVAS.Width / 5) * 3, PCT_CANVAS.Height - 300, 250, 300);
            ball.Update();
            ball.Render(g);

            DIR.Text = "DIR: " + ball.dir.ToString();
            SPEED.Text = "SPEED: " + ball.speedX + " , " + ball.speedY;
            SIZE.Text = "SIZE: " + ball.diameter;


            PCT_CANVAS.Invalidate();


        }

        private void BTN_Click(object sender, EventArgs e)
        {
            Init();
        }
    }
}
