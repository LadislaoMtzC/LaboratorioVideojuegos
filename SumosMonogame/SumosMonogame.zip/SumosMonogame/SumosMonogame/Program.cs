﻿
using var game = new SumosMonogame.Game1();
game.Run();
